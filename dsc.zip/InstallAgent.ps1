
configuration InstallAgent
{
    param
    (
        [Parameter(Mandatory)]
        [String]$AgentPackageUrl,

		[System.Management.Automation.PSCredential]$SasToken,
		[String]$PackageDirName="D:\vFive",
		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$AdminAccount,
		[Parameter(Mandatory)]
		[String]$AgentAddress,
		[String]$AgentName=$env:COMPUTERNAME,
		[uint16]$Port=15003,
		[uint16]$DataPort=15004,
		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$AgentAccount,
		[Parameter(Mandatory)]
		[String]$ManagerAddress,
		[uint16]$ManagerPort=15001,
		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$Passphrase
    )
	
	Import-DscResource -ModuleName cvFive, xNetworking
	if(!$AgentName -or $AgentName -eq "")
	{
		$AgentName=$env:COMPUTERNAME
	}
	
	Node localhost
	{
		LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

		# Install the .NET 4.5 feature
        WindowsFeature NetFramework45
        {
            Ensure = "Present"
            Name = "NET-Framework-45-Features"
        }

		xFirewall vFiveAgentFirewallRule
        {
            Direction = "Inbound"
            Name = "vFive-Agent-TCP-In"
            DisplayName = "vFive Agent"
            Description = "Inbound rule for vFive agent."
            DisplayGroup = "vFive"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = "$Port", "$DataPort"
            Ensure = "Present"
        }

		$GroupDependsOn = $null
		#Create local account
		if(!(IsDomainAccount -Credential $AgentAccount))
		{
			if($AgentAccount.UserName -ne $AdminAccount.UserName)
			{
				User CreateLocalAccount
				{
					UserName = $AgentAccount.UserName
					Ensure = "Present"
					Disabled = $false
					Password = $AgentAccount
					PasswordNeverExpires = $true
				}
				$GroupDependsOn = "[User]CreateLocalAccount"
			}
			else
			{
				$AgentAccount = $AdminAccount
			}
		}

		Group AddvFiveAgentAccountToLocalAdminsGroup
		{
			GroupName = "Administrators"
			Credential = $AdminAccount
			MembersToInclude = $AgentAccount.UserName
			Ensure = "Present"
			DependsOn = $GroupDependsOn
		}

		#Install manager
		cInstallAgent InstallvFiveAgent
		{
			AgentAddress = $AgentAddress
			AgentName = $AgentName
			AgentPort = $Port
			AgentDataPort = $DataPort
			AgentAccount = $AgentAccount
			ManagerAddress = $ManagerAddress
			ManagerPort = $ManagerPort
			Passphrase = $Passphrase
			AgentPackageUrl = $AgentPackageUrl
			SasToken = $SasToken
			PackageDirName = $PackageDirName
			DependsOn = "[WindowsFeature]NetFramework45", "[xFirewall]vFiveAgentFirewallRule", "[Group]AddvFiveAgentAccountToLocalAdminsGroup"
		}
	}

}

function IsDomainAccount([System.Management.Automation.PSCredential]$Credential)
{
	if($Credential.GetNetworkCredential().Domain `
		-and $Credential.GetNetworkCredential().Domain -ne "." `
		-and $Credential.GetNetworkCredential().Domain -ne $env:COMPUTERNAME)
	{
		return $true
	}
	return $false
}

