
function DownloadPackage([String]$PackageUrl, [PSCredential]$SasToken, [String]$PackageDirName)
{
	if (!(Test-Path $PackageDirName)) {
		New-Item -Path $PackageDirName -ItemType Directory | Out-Null
	}
	$PackageFileName = Split-Path $PackageUrl -Leaf
	$PackagePath = Join-Path -Path $PackageDirName -ChildPath $PackageFileName
	Write-Verbose "Download url '$($PackageUrl)' to location '$($PackagePath)'"
	if($SasToken)
	{
		Write-Verbose "Translating sas token."
		$PackageUrl = $PackageUrl + $(ConvertToString -SecureString $SasToken.Password)
	}
	
	if (Test-Path $PackagePath) {
		Remove-Item -Path $PackagePath -ErrorAction SilentlyContinue | Out-Null
	}
	Write-Verbose "Download started."
	$oldVerbose = $VerbosePreference
	$VerbosePreference = "SilentlyContinue"
	try
	{
		Invoke-WebRequest -Uri $PackageUrl -OutFile $PackagePath | Out-Null
	}
	finally
	{
		$VerbosePreference = $oldVerbose
	}
	return $PackagePath
}

function InstallFiles([string]$PackagePath, [string]$InstallPath)
{
	Write-Verbose "Install to location '$($InstallPath)'"
	Add-Type -Assembly System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($PackagePath, $InstallPath)
}


function ReflectionInvokeStaticMethod([System.Reflection.Assembly]$Assembly, [string]$TypeName, [string]$MethodName, [Type[]]$ParamTypes, [object[]]$Parameters)
{
	$type = $Assembly.GetType($TypeName, $true, $true);
	$method = ReflectionGetMethod -Type $type -MethodName $MethodName -ParamTypes $ParamTypes
	return $method.Invoke($null, $Parameters)
}

function ReflectionGetMethod([Type]$Type, [string]$MethodName, [Type[]]$ParamTypes)
{
	$bindingFlags = 61
	if(!$ParamTypes)
	{
		[Type[]]$ParamTypes = @()
	}
	return $Type.GetMethod($MethodName, $bindingFlags, $null, $ParamTypes, $null)
}

function InitializeIISCommand()
{
	if(!(Get-Module -Name WebAdministration))
	{
		Write-Verbose "Initialize IIS module."
		Import-Module WebAdministration
		if(!(Get-Module -ListAvailable -Name WebAdministration))
		{
			Throw "Please ensure that WebAdministration module is installed."
		}
	}
}

function CreateApplicationPool([string]$Name, [PSCredential]$User)
{
	InitializeIISCommand
	Write-Verbose "Start to create application pool '$($Name)'"
	$pool = New-WebAppPool -Name $Name
	$pool.managedRuntimeVersion = "v4.0"
	$pool.enable32BitAppOnWin64 = $false
	if($User)
	{
		$pool.processModel.identityType = "SpecificUser"
		$pool.processModel.userName = $User.UserName
		$pool.processModel.password = ConvertToString -SecureString $User.Password
	}
	$pool | Set-Item
	$pool = $pool | Get-Item
	$pool.Recycle() | Out-Null
	return $pool
}

function IsApplicationPoolExist([string]$Name)
{
	InitializeIISCommand
	$pool = Get-Item -Path IIS:\AppPools\* | ?{$_.Name -eq $Name}
	if($pool)
	{
		return $true
	}
	return $false
}

function StartApplicationPool([string]$Name)
{
	InitializeIISCommand
	Start-WebAppPool -Name $Name
}

function StopApplicationPool([string]$Name)
{
	InitializeIISCommand
	Stop-WebAppPool -Name $Name
}

function IsWebSiteExist([string]$Name)
{
	InitializeIISCommand
	$site = Get-Website -Name $Name
	if($site)
	{
		return $true
	}
	return $false
}

function CreateWebSite([string]$Name, [string]$PhysicalPath, [switch]$StartWebSite, 
	[string]$ApplicationPool, [uint16]$Port, [string]$IPAddress, [string]$HostHeader, 
	[switch]$Ssl, [string]$CertificateThumbprint, [string]$CertificateStoreName, 
	[string[]]$DefaultPage)
{
	InitializeIISCommand
	$PSBoundParameters.Remove("StartWebSite") | Out-Null
	$PSBoundParameters.Remove("DefaultPage") | Out-Null
	$PSBoundParameters.Remove("CertificateThumbprint") | Out-Null
	$PSBoundParameters.Remove("CertificateStoreName") | Out-Null
	$Website = New-Website @PSBoundParameters -ErrorAction Stop
	Stop-Website $Name -ErrorAction Stop
	if($Ssl -and $CertificateThumbprint -and $CertificateStoreName)
	{
		$binding = Get-WebBinding -Name $Name -Port $Port
        $binding.AddSslCertificate($CertificateThumbprint, $CertificateStoreName) | Out-Null
	}
	if($DefaultPage)
    {
	    UpdateDefaultPages -Name $Name -DefaultPage $DefaultPage | Out-Null
	}
	Write-Verbose "Create web site '$($Name)' successfully."
	if($StartWebSite)
	{
		Start-Sleep -s 1
		Start-Website -Name $Name
		Write-Verbose "Start web site '$($Name)' complete."
	}
	return $Website
}

function UpdateDefaultPages
{
    param
    (
        [string] $Name,

        [string[]] $DefaultPage
    )
	
	$allDefaultPage = @(Get-WebConfiguration //defaultDocument/files/*  -PSPath (Join-Path "IIS:\sites\" $Name) |%{Write-Output $_.value})

    foreach($page in $DefaultPage )
    {
        if(-not ($allDefaultPage  -icontains $page))
        {   
			Write-Verbose("Deafult page for website $Name has been updated to $page");
            Add-WebConfiguration //defaultDocument/files -PSPath (Join-Path "IIS:\sites\" $Name) -Value @{value = $page }
        }
    }
}

function IsServiceExist([string]$Name)
{
	$service = Get-Service | ?{ $_.Name -eq $Name }
	if($service)
	{
		return $true
	}
	return $false
}

function InstallService([string]$Name, [string]$BinaryPathName, [string]$DisplayName, [string]$Description)
{
	Write-Verbose "Install service '$($Name)', Path: '$($BinaryPathName)'"
	return New-Service @PSBoundParameters -StartupType Automatic
}

function StartService([string]$Name)
{
	Write-Verbose "Start service '$($Name)'"
	Start-Service -Name $Name
}

function ConvertToString([SecureString]$SecureString)
{
	 $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureString)
	 try
	 {
	 	$str = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
	 }
	 finally
	 {
	 	[System.Runtime.InteropServices.Marshal]::FreeBSTR($bstr)
	 }
	 return $str
}