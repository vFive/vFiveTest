
function Get-TargetResource
{
    param
    (
		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$SqlServerInstanceName,

		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [PSCredential] $SqlCredential,

		[Bool]$EnableSqlAuthentication
    )

    $retval = @{
		SqlServerInstanceName = $SqlServerInstanceName
        SqlCredential = $SqlCredential
		EnableSqlAuthentication = $EnableSqlAuthentication
    }

    $retval
}

function Set-TargetResource
{
    param
    (
		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$SqlServerInstanceName,

		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [PSCredential] $SqlCredential,

		[Bool]$EnableSqlAuthentication
    )

	[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo") | Out-Null
    $sc = New-Object Microsoft.SqlServer.Management.Common.ServerConnection
    if ($SqlCredential)
    {
        $sc.ConnectAsUser = $true
        if ($SqlCredential.GetNetworkCredential().Domain -and $SqlCredential.GetNetworkCredential().Domain -ne $env:COMPUTERNAME)
        {
            $sc.ConnectAsUserName = "$($SqlCredential.GetNetworkCredential().UserName)@$($SqlCredential.GetNetworkCredential().Domain)"
        }
        else
        {
            $sc.ConnectAsUserName = $SqlCredential.GetNetworkCredential().UserName
        }
        $sc.ConnectAsUserPassword = $SqlCredential.GetNetworkCredential().Password
    }
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
    $s = New-Object Microsoft.SqlServer.Management.Smo.Server $sc

    if($EnableSqlAuthentication)
	{
		if($s.Settings.LoginMode -ne [Microsoft.SqlServer.Management.SMO.ServerLoginMode]::Mixed)
		{
			$s.Settings.LoginMode = [Microsoft.SqlServer.Management.SMO.ServerLoginMode]::Mixed
			$s.Alter()
			Restart-SqlServer -InstanceName $SqlServerInstanceName -Server $s
		}
	}
	else
	{
		if($s.Settings.LoginMode -ne [Microsoft.SqlServer.Management.SMO.ServerLoginMode]::Integrated)
		{
			$s.Settings.LoginMode = [Microsoft.SqlServer.Management.SMO.ServerLoginMode]::Integrated
			$s.Alter()
			Restart-SqlServer -InstanceName $SqlServerInstanceName -Server $s
		}
	}
}

function Test-TargetResource
{
    param
    (
		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$SqlServerInstanceName,

		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [PSCredential] $SqlCredential,

		[Bool]$EnableSqlAuthentication
    )

	return $false
}

function Restart-SqlServer([string]$InstanceName, [Microsoft.SqlServer.Management.Smo.Server]$Server)
{
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement") | Out-Null
    $mc = New-Object Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer $Server.Name
    $list = $InstanceName.Split("\")
    if ($list.Count -gt 1)
    {
        $InstanceName = $list[1]
    }
    else
    {
        $InstanceName = "MSSQLSERVER"
    }
    $svc = $mc.Services[$InstanceName]

    Write-Verbose -Message "Restarting SQL server instance '$($InstanceName)' ..."
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.WmiEnum") | Out-Null
    $svc.Stop()
    $svc.Refresh()
    while ($svc.ServiceState -ne [Microsoft.SqlServer.Management.Smo.Wmi.ServiceState]::Stopped)
    {
        $svc.Refresh()
    }

    $svc.Start()
    $svc.Refresh()
    while ($svc.ServiceState -ne [Microsoft.SqlServer.Management.Smo.Wmi.ServiceState]::Running)
    {
        $svc.Refresh()
    }
}

Export-ModuleMember -Function *-TargetResource
