
function Get-TargetResource
{
    param
    (
        [Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$AgentAddress,

		[ValidateNotNullOrEmpty()]
		[String]$AgentName = $enc:COMPUTERNAME,

		[ValidateNotNullOrEmpty()]
        [uint16] $AgentPort=15003,

		[ValidateNotNullOrEmpty()]
        [uint16] $AgentDataPort=15004,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[PSCredential]$AgentAccount,

        [Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$ManagerAddress,

        [ValidateNotNullOrEmpty()]
        [uint16] $ManagerPort=15001,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[PSCredential]$Passphrase,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
        [String]$AgentPackageUrl,

		[PSCredential]$SasToken,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$PackageDirName
    )

    $retval = @{
    }

    $retval
}

function Set-TargetResource
{
    param
    (
		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$AgentAddress,

		[ValidateNotNullOrEmpty()]
		[String]$AgentName = $enc:COMPUTERNAME,

		[ValidateNotNullOrEmpty()]
        [uint16] $AgentPort=15003,

		[ValidateNotNullOrEmpty()]
        [uint16] $AgentDataPort=15004,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[PSCredential]$AgentAccount,

        [Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$ManagerAddress,

        [ValidateNotNullOrEmpty()]
        [uint16] $ManagerPort=15001,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[PSCredential]$Passphrase,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
        [String]$AgentPackageUrl,

		[PSCredential]$SasToken,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$PackageDirName
    )

	Import-Module "$($PSScriptRoot + '\..\..\vFiveCommon.psm1')"
	Init
	
    Write-Verbose -Message "Start to install agent."
	$PackagePath = DownloadPackage -PackageUrl $AgentPackageUrl -SasToken $SasToken -PackageDirName $PackageDirName

	$UnzipPath = Join-Path -Path $env:ProgramFiles -ChildPath "AvePoint"
	InstallFiles -PackagePath $PackagePath -InstallPath $UnzipPath
	$InstallRootPath = Join-Path -Path $UnzipPath -ChildPath "vFive\Agent"
	$BinPath = Join-Path -Path $InstallRootPath -ChildPath "bin"
	$AgentConfigPath = Join-Path -Path $BinPath -ChildPath "AgentCommonVCEnv.config"
	$AgentServicePath = Join-Path -Path $BinPath -ChildPath "vFiveAgentService.exe"
	
	SetRegistry -InstalledLocation $InstallRootPath

	#install certicate
	Set-Location -Path $BinPath
	$asemblyPath = Join-Path -Path $BinPath -ChildPath "AgentCommonPostInstall.exe"
	$asemblyPath2 = Join-Path -Path $BinPath -ChildPath "CommonUtility.dll"
	$asemblyPath3 = Join-Path -Path $BinPath -ChildPath "CryptographyAlgorithm.dll"
	[System.Reflection.Assembly]::LoadFile($asemblyPath2)
	[System.Reflection.Assembly]::LoadFile($asemblyPath3)
	$assembly = [System.Reflection.Assembly]::LoadFile($asemblyPath)
	$CertificateStoreName = "My"
	$CertificateThumbprint = ImportBuildInCertificate -Assembly $assembly -Location $InstallPath

	#Write config file
	$configFilePath = Join-Path -Path $BinPath -ChildPath "AgentCommonPostInstall.exe.xml"
	$agentDomain = $AgentAccount.GetNetworkCredential().Domain
	if(!$agentDomain -or $agentDomain -eq ".")
	{
		$agentDomain = ""
	}
	$ConfigParameters = @{
		"passwordEncrypted" = $true;
		"agentName" = $AgentName;
		"agentAddress" = $AgentAddress;
		"agentType" = "";
		"agentDomain" = $agentDomain;
		"agentPort" = $AgentPort;
		"agentDataPort" = $AgentDataPort;
		"agentUsername" = $AgentAccount.GetNetworkCredential().UserName;
		"agentPassword" = $(EncryptPassword -SecureString $AgentAccount.Password -Assembly $assembly);
		"certThumbprint" = $CertificateThumbprint;
		"managerAddress" = $ManagerAddress;
		"managerPort" = $ManagerPort;
		"passphraseHash" = $(ComputePassphraseHass -Passphrase $($Passphrase.GetNetworkCredential().Password) -Assembly $assembly);
		"productType" = "";
	}
	Write-Verbose "Start to set configure file $($configFilePath)."
	SetConfigProperties -FilePath $configFilePath -Properties $ConfigParameters
	
	Write-Verbose "Start to install agent."
	$process = Start-Process -FilePath $assembly -ArgumentList @("-I") -WorkingDirectory $BinPath
	Wait-Process -InputObject $process
	if($process.ExitCode -ne 0)
	{
		Write-Error -Message "Install failed, exit code is $($process.ExitCode)"
	}

	Remove-Item -Path $configFilePath
}

function Test-TargetResource
{
    param
    (
		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$AgentAddress,

		[ValidateNotNullOrEmpty()]
		[String]$AgentName = $enc:COMPUTERNAME,

		[ValidateNotNullOrEmpty()]
        [uint16] $AgentPort=15003,

		[ValidateNotNullOrEmpty()]
        [uint16] $AgentDataPort=15004,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[PSCredential]$AgentAccount,

        [Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$ManagerAddress,

        [ValidateNotNullOrEmpty()]
        [uint16] $ManagerPort=15001,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[PSCredential]$Passphrase,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
        [String]$AgentPackageUrl,

		[PSCredential]$SasToken,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$PackageDirName
    )

	Import-Module "$($PSScriptRoot + '\..\..\vFiveCommon.psm1')"
	Init
	Write-Verbose "Install agent test."
	#Check if the package is installed.
	$installLocation = GetInstallLocation
	if(!$installLocation -or !(Test-Path $installLocation))
	{
		Write-Verbose "The package is not installed."
		return $false
	}
	Write-Verbose "The package install path is '$($installLocation)'"
	
	if(!(IsServiceExist -Name "vFive Agent Service"))
	{
		Write-Verbose "vFive Agent Service does not exist."
		return $false
	}
	return $true	
}

function ImportBuildInCertificate([System.Reflection.Assembly]$Assembly, [string]$Location)
{
	Write-Verbose "Install build-in certificate."
	return ReflectionInvokeStaticMethod -Assembly $Assembly -TypeName "AvePoint.Service.Marketplace.MarketplaceUtil" -MethodName "InstallBuildinCertificate" -ParamTypes @([string]) -Parameters @($Location)
}

function ComputePassphraseHass([System.Reflection.Assembly]$Assembly, [string]$Passphrase)
{
	return ReflectionInvokeStaticMethod -Assembly $Assembly -TypeName "AvePoint.Service.Marketplace.MarketplaceUtil" -MethodName "HashPassphrase" -ParamTypes @([string]) -Parameters @($Passphrase)
}

function EncryptPassword([System.Reflection.Assembly]$Assembly, [SecureString]$SecureString)
{
	$password = ConvertToString -SecureString $SecureString
	return ReflectionInvokeStaticMethod -Assembly $Assembly -TypeName "AvePoint.Service.Marketplace.MarketplaceUtil" -MethodName "EncryptPassword" -ParamTypes @([string]) -Parameters @($password)
}

function SetConfigProperties([string]$FilePath, [Hashtable]$Properties)
{
	[System.Configuration.ExeConfigurationFileMap]$map = New-Object -TypeName "System.Configuration.ExeConfigurationFileMap"
	$map.ExeConfigFilename = $FilePath
	[System.Configuration.Configuration]$envConfiguration = [System.Configuration.ConfigurationManager]::OpenMappedExeConfiguration($map, 0)
	$Properties.GetEnumerator() | %{
		$envConfiguration.AppSettings.Settings.Add("$($_.Name)", "$($_.Value)")
	}
	$envConfiguration.Save()
}

function SetRegistry([string]$InstalledLocation)
{
	$vFiveKey = "HKLM:\SOFTWARE\AvePoint\vFive\vFive Agent"
	if(-not (Test-Path $vFiveKey -ErrorAction SilentlyContinue))
    {
        New-Item -Path "HKLM:\SOFTWARE\AvePoint\vFive" -Name '\vFive Agent' -Force -ErrorAction SilentlyContinue
    }
	if (-not (Get-ItemProperty $vFiveKey -Name "InstallPath" -ErrorAction SilentlyContinue))
	{
		New-ItemProperty $vFiveKey -Name "InstallPath" -value $InstalledLocation -PropertyType string -ErrorAction SilentlyContinue
	}
	$uninstallKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\vFive Agent"
	if(-not (Test-Path $uninstallKey -ErrorAction SilentlyContinue))
    {
        New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" -Name '\vFive Agent' -Force -ErrorAction SilentlyContinue
    }
	$versionConfig = [xml](Get-Content -Path $(Join-Path -Path $InstalledLocation -ChildPath "ServiceVersion.config"))
	$version = $xml.configuration.properties.ProductVersion
	$values = @{
		"DisplayIcon" = $(Join-Path -Path $InstalledLocation -ChildPath "Uninstall\Images\AgentConfigurationTool.ico");
		"DisplayName" = "vFive Agent";
		"DisplayVersion" = "$version";
		"EstimatedSize" = "";
		"HelpLink" = "http://www.AvePoint.com/support";
		"InstallDate" = "";
		"InstalledLocation" = $InstalledLocation;
		"InstallSource" = "";
		"Publisher" = "AvePoint, Inc.";
		"UninstallString" = "$(Join-Path -Path $InstalledLocation -ChildPath "Uninstall\UnInstall.exe") vFiveAgent";
		"URLInfoAbout" = "http://www.AvePoint.com";
		"URLUpdateInfo" = "http://www.AvePoint.com/Products";
	}
	$values.GetEnumerator() | %{
		if (-not (Get-ItemProperty $uninstallKey -Name $_.Name -ErrorAction SilentlyContinue))
		{
			New-ItemProperty $uninstallKey -Name $_.Name -value $_.Value -PropertyType string -ErrorAction SilentlyContinue
		}
	}
}

function GetInstallLocation()
{
	$vFiveKey = "HKLM:\SOFTWARE\AvePoint\vFive\vFive Agent"
	$installLocation = Get-ItemProperty $vFiveKey -Name "InstallPath" -ErrorAction SilentlyContinue
	if($installLocation)
	{
		return $installLocation.InstallPath
	}
	
	$uninstallKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\vFive Agent"
	$installLocation = Get-ItemProperty $uninstallKey -Name "InstalledLocation" -ErrorAction SilentlyContinue
	if($installLocation)
	{
		return $installLocation.InstalledLocation
	}

	return $null
}

function Init()
{
	$global:VerbosePreference = "Continue"
}

Export-ModuleMember -Function *-TargetResource
