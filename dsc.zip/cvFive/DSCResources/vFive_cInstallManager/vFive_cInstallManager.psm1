
function Get-TargetResource
{
    param
    (
        [Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$SqlServerInstanceName,

		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [PSCredential] $SqlCredential,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$DatabaseName,

		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [PSCredential] $ApplicationPoolAccount,

		[Bool]$IsIntegrated,
		[uint16]$Port = 15001,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
        [String]$ManagerPackageUrl,

		[PSCredential]$SasToken,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$PackageDirName
    )

    $retval = @{
        SqlServerInstanceName = $SqlServerInstanceName
        SqlCredential = $SqlCredential
		DatabaseName = $DatabaseName
		ManagerPackageUrl = $ManagerPackageUrl
		ManagerPackageSetParametersUrl = $ManagerPackageSetParametersUrl
		SasToken = $SasToken
		PackageDirName = $PackageDirName
    }

    $retval
}

function Set-TargetResource
{
    param
    (
        [Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$SqlServerInstanceName,

		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [PSCredential] $SqlCredential,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$DatabaseName,

		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [PSCredential] $ApplicationPoolAccount,

		[Bool]$IsIntegrated,
		[uint16]$Port = 15001,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
        [String]$ManagerPackageUrl,

		[PSCredential]$SasToken,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$PackageDirName
    )

	Import-Module "$($PSScriptRoot + '\..\..\vFiveCommon.psm1')"
	Init
	
    Write-Verbose -Message "Start to install manager."
	$PackagePath = DownloadPackage -PackageUrl $ManagerPackageUrl -SasToken $SasToken -PackageDirName $PackageDirName

	$UnzipPath = Join-Path -Path $env:ProgramFiles -ChildPath "AvePoint"
	InstallFiles -PackagePath $PackagePath -InstallPath $UnzipPath
	$InstallRootPath = Join-Path -Path $UnzipPath -ChildPath "vFive\Manager"
	$InstallPath = Join-Path -Path $InstallRootPath -ChildPath "Install"
	$ControlPath = Join-Path -Path $InstallRootPath -ChildPath "Control"
	$WebConfigPath = Join-Path -Path $ControlPath -ChildPath "Web.config"
	$TimerConfigPath = Join-Path -Path $ControlPath -ChildPath "bin\vFiveTimerService.exe.config"
	$TimerServicePath = Join-Path -Path $ControlPath -ChildPath "bin\vFiveTimerService.exe"
	
	SetRegistry -InstalledLocation $InstallRootPath

	#install certicate
	Set-Location -Path $InstallPath
	$asemblyPath = Join-Path -Path $InstallPath -ChildPath "vFive.PostInstall.exe"
	$asemblyPath2 = Join-Path -Path $InstallPath -ChildPath "CryptographyAlgorithm.dll"
	$assembly = [System.Reflection.Assembly]::LoadFile($asemblyPath)
	[System.Reflection.Assembly]::LoadFile($asemblyPath2)
	$CertificateStoreName = "My"
	$CertificateThumbprint = ImportBuildInCertificate -Assembly $assembly -Location $InstallPath

	#Create Application Pool
	$ApplicationPoolName = "vFive"
	if(!(IsApplicationPoolExist -Name $ApplicationPoolName))
	{
		$applicationPool = CreateApplicationPool -Name $ApplicationPoolName -User $ApplicationPoolAccount
	}
	StopApplicationPool -Name $ApplicationPoolName

	#Create Website
	$WebSiteName = "vFive"
	if(!(IsWebSiteExist -Name $WebSiteName))
	{
		$webSite = CreateWebSite -Name $WebSiteName -PhysicalPath $ControlPath -StartWebSite -Port $Port `
		-ApplicationPool $ApplicationPoolName -Ssl -CertificateThumbprint $CertificateThumbprint -CertificateStoreName $CertificateStoreName
	}

	#Write web.config
	$ConfigParameters = @{
		"ControlServicePort" = $Port;
		"ConfigDatabaseInstance" = $SqlServerInstanceName;
		"ConfigDatabaseName" = $DatabaseName;
		"ConfigDatabaseAccount" = $SqlCredential;
		"AppPoolName" = $ApplicationPoolName;
		"AppPoolAccount" = $ApplicationPoolAccount;
		"WebSiteName" = $WebSiteName;
		"ConfigDatabaseIsIntegrated" = $IsIntegrated;
		"ControlServiceAddress" = $env:COMPUTERNAME;
		"Assembly" = $assembly;
	}
	Write-Verbose "Start to set configure properties."
	SetWebConfigProperties -FilePath $WebConfigPath @ConfigParameters
	$ConfigParameters.Add("ControlServiceSchema", "https")
	SetTimerConfigProperties -FilePath $TimerConfigPath @ConfigParameters
	
    #=======================================  
    # Reset IIS on the server  
    #=======================================  
    Write-Verbose "Start application pool";  
    StartApplicationPool -Name $ApplicationPoolName

	#Install timer service
	$TimerServiceName = "vFive Timer Service"
	if(!(IsServiceExist -Name "vFive Timer Service"))
	{
		InstallService -Name $TimerServiceName -BinaryPathName $TimerServicePath -DisplayName $TimerServiceName -Description $TimerServiceName
	}
	StartService -Name $TimerServiceName
}

function Test-TargetResource
{
    param
    (
		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$SqlServerInstanceName,

		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [PSCredential] $SqlCredential,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$DatabaseName,

		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [PSCredential] $ApplicationPoolAccount,

		[Bool]$IsIntegrated,
		[uint16]$Port = 15001,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
        [String]$ManagerPackageUrl,

		[PSCredential]$SasToken,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$PackageDirName
    )

	Import-Module "$($PSScriptRoot + '\..\..\vFiveCommon.psm1')"
	Init
	Write-Verbose "Install manager test."
	#Check if the package is installed.
	$installLocation = GetInstallLocation
	if(!$installLocation -or !(Test-Path $installLocation))
	{
		Write-Verbose "The package is not installed."
		return $false
	}
	Write-Verbose "The package install path is '$($installLocation)'"
	$webConfigPath = Join-Path -Path $installLocation -ChildPath "Control\Web.config"
	if(!(Test-Path $webConfigPath))
	{
		Write-Verbose "IIS configure file '$($webConfigPath)' not exist."
		return $false
	}
	$xml = [xml](Get-Content -Path $webConfigPath)
	$appSettings = $xml.configuration.appSettings.add

	$appSettings | %{
		if($_.key -eq "AppPoolName")
		{
			$applicationPoolName = $_.value
		}
		if($_.key -eq "WebSiteName")
		{
			$webSite = $_.value
		}
	}
	
	if(!(IsApplicationPoolExist -Name $applicationPoolName))
	{
		Write-Verbose "Application pool '$($applicationPoolName)' does not exist."
		return $false
	}
	if(!(IsWebSiteExist -Name $webSite))
	{
		Write-Verbose "IIS site '$($webSite)' does not exist."
		return $false
	}
	if(!(IsServiceExist -Name "vFive Timer Service"))
	{
		Write-Verbose "vFive Timer Service does not exist."
		return $false
	}
	return $true	
}

function ImportBuildInCertificate([System.Reflection.Assembly]$Assembly, [string]$Location)
{
	Write-Verbose "Install build-in certificate."
	return ReflectionInvokeStaticMethod -Assembly $Assembly -TypeName "AvePoint.vFive.PostInstall.InstallUtility" -MethodName "InstallBuildinCertificate" -ParamTypes @([string]) -Parameters @($Location)
}

function SetWebConfigProperties([string]$FilePath, [uint16]$ControlServicePort, [string]$ControlServiceAddress,
	[string]$ConfigDatabaseInstance, [string]$ConfigDatabaseName, [switch]$ConfigDatabaseIsIntegrated,
	[PSCredential]$ConfigDatabaseAccount, [string]$AppPoolName, [PSCredential]$AppPoolAccount,
	[string]$WebSiteName, [System.Reflection.Assembly]$Assembly
)
{
	$PSBoundParameters.Remove("FilePath")
	$PSBoundParameters.Remove("ConfigDatabaseAccount")
	$PSBoundParameters.Remove("AppPoolAccount")
	if($ConfigDatabaseAccount)
	{
		$PSBoundParameters.Add("ConfigDatabaseUsername", $ConfigDatabaseAccount.UserName)
		$PSBoundParameters.Add("ConfigDatabasePassword", "$(EncryptPassword -SecureString $ConfigDatabaseAccount.Password -Assembly $Assembly)")
	}
	if($AppPoolAccount)
	{
		$PSBoundParameters.Add("AppPoolUserName", $AppPoolAccount.UserName)
		$PSBoundParameters.Add("AppPoolPassword", "$(EncryptPassword -SecureString $AppPoolAccount.Password -Assembly $Assembly)")
	}
	$xml = [xml](Get-Content -Path $FilePath)
	$appSettings = $xml.configuration.appSettings.add
	$appSettings | %{
		foreach($key in $PSBoundParameters.Keys)
		{
			if($key -eq $_.key)
			{
				$_.value = "$($PSBoundParameters[$key])"
			}
		}
	}
	$xml.Save($FilePath)
}

function SetTimerConfigProperties([string]$FilePath, [string]$ControlServiceSchema,
	[string]$ControlServiceAddress, [uint16]$ControlServicePort, [string]$ConfigDatabaseInstance,
	[string]$ConfigDatabaseName, [switch]$ConfigDatabaseIsIntegrated, [PSCredential]$ConfigDatabaseAccount,
	[string]$AppPoolName, [PSCredential]$AppPoolAccount, [string]$WebSiteName, [System.Reflection.Assembly]$Assembly
)
{
	$PSBoundParameters.Remove("FilePath")
	$PSBoundParameters.Remove("ConfigDatabaseAccount")
	$PSBoundParameters.Remove("AppPoolAccount")
	if($ConfigDatabaseAccount)
	{
		$PSBoundParameters.Add("ConfigDatabaseUsername", $ConfigDatabaseAccount.UserName)
		$PSBoundParameters.Add("ConfigDatabasePassword", "$(EncryptPassword -SecureString $ConfigDatabaseAccount.Password -Assembly $Assembly)")
	}
	if($AppPoolAccount)
	{
		$PSBoundParameters.Add("AppPoolUserName", $AppPoolAccount.UserName)
		$PSBoundParameters.Add("AppPoolPassword", "$(EncryptPassword -SecureString $AppPoolAccount.Password -Assembly $Assembly)")
	}
	$xml = [xml](Get-Content -Path $FilePath)
	$appSettings = $xml.configuration.appSettings.add
	$appSettings | %{
		foreach($key in $PSBoundParameters.Keys)
		{
			if($key -eq $_.key)
			{
				$_.value = "$($PSBoundParameters[$key])"
			}
		}
	}
	$xml.Save($FilePath)
}

function EncryptPassword([SecureString]$SecureString, [System.Reflection.Assembly]$Assembly)
{
	$password = ConvertToString -SecureString $SecureString
	return ReflectionInvokeStaticMethod -Assembly $Assembly -TypeName "AvePoint.vFive.PostInstall.PowerShellInstallEncryptUtil" -MethodName "Encrypt" -ParamTypes @([string]) -Parameters @($password)
}

function SetRegistry([string]$InstalledLocation)
{
	$vFiveKey = "HKLM:\SOFTWARE\AvePoint\vFive\vFive Manager"
	if(-not (Test-Path $vFiveKey -ErrorAction SilentlyContinue))
    {
        New-Item -Path "HKLM:\SOFTWARE\AvePoint\vFive" -Name '\vFive Manager' -Force -ErrorAction SilentlyContinue
    }
	if (-not (Get-ItemProperty $vFiveKey -Name "InstallPath" -ErrorAction SilentlyContinue))
	{
		New-ItemProperty $vFiveKey -Name "InstallPath" -value $InstalledLocation -PropertyType string -ErrorAction SilentlyContinue
	}
	$uninstallKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\vFive Manager"
	if(-not (Test-Path $uninstallKey -ErrorAction SilentlyContinue))
    {
        New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" -Name '\vFive Manager' -Force -ErrorAction SilentlyContinue
    }
	$versionConfig = [xml](Get-Content -Path $(Join-Path -Path $InstalledLocation -ChildPath "Install\ServiceVersion.config"))
	$version = $xml.configuration.properties.ProductVersion
	$values = @{
		"DisplayIcon" = $(Join-Path -Path $InstalledLocation -ChildPath "Install\Shortcut.ico");
		"DisplayName" = "vFive Manager";
		"DisplayVersion" = "$version";
		"EstimatedSize" = "";
		"HelpLink" = "http://www.AvePoint.com/support";
		"InstallDate" = "";
		"InstalledLocation" = $InstalledLocation;
		"InstallSource" = "";
		"Publisher" = "AvePoint, Inc.";
		"UninstallString" = "$(Join-Path -Path $InstalledLocation -ChildPath "Install\UnInstall.exe") vFiveManager";
		"URLInfoAbout" = "http://www.AvePoint.com";
		"URLUpdateInfo" = "http://www.AvePoint.com/Products";
	}
	$values.GetEnumerator() | %{
		if (-not (Get-ItemProperty $uninstallKey -Name $_.Name -ErrorAction SilentlyContinue))
		{
			New-ItemProperty $uninstallKey -Name $_.Name -value $_.Value -PropertyType string -ErrorAction SilentlyContinue
		}
	}
}

function GetInstallLocation()
{
	$vFiveKey = "HKLM:\SOFTWARE\AvePoint\vFive\vFive Manager"
	$installLocation = Get-ItemProperty $vFiveKey -Name "InstallPath" -ErrorAction SilentlyContinue
	if($installLocation)
	{
		return $installLocation.InstallPath
	}
	
	$uninstallKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\vFive Manager"
	$installLocation = Get-ItemProperty $uninstallKey -Name "InstalledLocation" -ErrorAction SilentlyContinue
	if($installLocation)
	{
		return $installLocation.InstalledLocation
	}

	return $null
}

function Init()
{
	$global:VerbosePreference = "Continue"
}

Export-ModuleMember -Function *-TargetResource
