
configuration InstallManager
{
    param
    (
        [Parameter(Mandatory)]
        [String]$ManagerPackageUrl,

		[System.Management.Automation.PSCredential]$SasToken,
		[String]$PackageDirName="D:\vFive",
		[String]$SqlServerInstanceName=$env:COMPUTERNAME,
		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$AdminCredential,
		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlCredential,
		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$ApplicationPoolAccount,
		[String]$DatabaseName="vFive_ControlDatabase",
		[uint16]$Port=15001,
		[Bool]$IsIntegrated = (IsDomainAccount -Credential $SqlCredential)
    )
	
	Import-DscResource -ModuleName cvFive, xNetworking
	if(!$SqlServerInstanceName -or $SqlServerInstanceName -eq "")
	{
		$SqlServerInstanceName=$env:COMPUTERNAME
	}
	if(!$ApplicationPoolAccount)
	{
		$ApplicationPoolAccount = $AdminCredential
	}

	Node localhost
	{
		LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

		# Install the IIS role
        WindowsFeature IIS
        {
            Ensure = "Present"
            Name = "Web-Server"
			IncludeAllSubFeature = $true
        }

        # Install the ASP .NET 4.5 role
        WindowsFeature AspNet45
        {
            Ensure = "Present"
            Name = "Web-Asp-Net45"
        }

		xFirewall vFiveManagerFirewallRule
        {
            Direction = "Inbound"
            Name = "vFive-Manager-TCP-In"
            DisplayName = "vFive Manager"
            Description = "Inbound rule for vFive manager."
            DisplayGroup = "vFive"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = "$Port"
            Ensure = "Present"
        }

		$GroupDependsOn = $null
		#Create local account
		if(!(IsDomainAccount -Credential $ApplicationPoolAccount))
		{
			if($ApplicationPoolAccount.UserName -ne $AdminCredential.UserName)
			{
				#TODO:
				User CreateLocalAccount
				{
					UserName = $ApplicationPoolAccount.UserName
					Ensure = "Present"
					Disabled = $false
					Password = $ApplicationPoolAccount
					PasswordNeverExpires = $true
				}
				$GroupDependsOn = "[User]CreateLocalAccount"
			}
			else
			{
				$ApplicationPoolAccount = $AdminCredential
			}
		}

		Group AddvFiveIISAccountToLocalAdminsGroup
		{
			GroupName = "Administrators"
			Credential = $AdminCredential
			MembersToInclude = $ApplicationPoolAccount.UserName
			Ensure = "Present"
			DependsOn = $GroupDependsOn
		}

		#Install manager
		cInstallManager InstallvFiveManager
		{
			SqlServerInstanceName = $SqlServerInstanceName
			SqlCredential = $SqlCredential
			DatabaseName = $DatabaseName
			ApplicationPoolAccount = $ApplicationPoolAccount
			IsIntegrated = $IsIntegrated
			Port = $Port
			ManagerPackageUrl = $ManagerPackageUrl
			SasToken = $SasToken
			PackageDirName = $PackageDirName
			DependsOn = "[WindowsFeature]IIS","[WindowsFeature]AspNet45", "[xFirewall]vFiveManagerFirewallRule", "[Group]AddvFiveIISAccountToLocalAdminsGroup"
		}
	}

}

function IsDomainAccount([System.Management.Automation.PSCredential]$Credential)
{
	if($Credential.GetNetworkCredential().Domain)
	{
		return $true
	}
	return $false
}

